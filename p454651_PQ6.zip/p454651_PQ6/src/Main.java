import com.opencsv.*;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.ListView;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        primaryStage.setTitle("CSV Data");
        HBox hbox = new HBox(listView);
        Scene scene = new Scene(hbox);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private static final String filePath = "Csv";
    public static ListView listView = new ListView();

    public static void main(String[] args) throws Exception{
        writeDataAtOnce1(filePath);
        readAllDataAtOnce(filePath);
        writeDataAtOnce2(filePath);
        readAllDataAtOnce(filePath);
        launch(args);
    }

    public static void readAllDataAtOnce(String file) throws Exception{
        // Create an object of file reader
        FileReader filereader = new FileReader(file);

        // create csvReader object and skip first Line
        CSVReader csvReader = new CSVReaderBuilder(filereader).build();
        List<String[]> allData = csvReader.readAll();

        // print Data
        for (String[] row : allData) {
            for (String cell : row) {
                listView.getItems().add(cell);

            }
            listView.getItems().add(" ");
        }
    }

    public static void writeDataAtOnce1(String filePath) throws Exception{
        // first create file object for file placed at location
        // specified by filepath
        File file = new File(filePath);

        // create FileWriter object with file as parameter
        FileWriter outputfile = new FileWriter(file);

        // create CSVWriter object filewriter object as parameter
        CSVWriter writer = new CSVWriter(outputfile);

        // create a List which contains String array
        List<String[]> data = new ArrayList<String[]>();
        data.add(new String[] { "Nicolas", "Brown", "p454651@tafe.wa.edu.au" });
        writer.writeAll(data);

        // closing writer connection
        writer.close();

    }

    public static void writeDataAtOnce2(String filePath) throws Exception{

        // first create file object for file placed at location
        // specified by filepath
        File file = new File(filePath);

        // create FileWriter object with file as parameter
        FileWriter outputfile = new FileWriter(file);

        // create CSVWriter object filewriter object as parameter
        CSVWriter writer = new CSVWriter(outputfile);

        // create a List which contains String array
        List<String[]> data = new ArrayList<String[]>();
        data.add(new String[] { "Josh", "Gray", "Josh.Gray@gmail.com" });
        writer.writeAll(data);

        // closing writer connection
        writer.close();
    }
}
