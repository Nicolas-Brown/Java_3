import com.opencsv.*;
import org.junit.Before;
import org.junit.Test;

import java.io.FileReader;
import java.util.List;

import static org.junit.Assert.assertEquals;

public class Testing {
    public static String print = "";

    private static final String filePath = "Csv";


    @Test
    public void readTest() throws Exception{
        print = testReadAllDataAtOnce(filePath);
        assertEquals("Josh Gray Josh.Gray@gmail.com ", print);
    }

    public static String testReadAllDataAtOnce(String file)throws Exception {
        String fin = "";
        // Create an object of file reader
        FileReader filereader = new FileReader(file);

        // create csvReader object and skip first Line
        CSVReader csvReader = new CSVReaderBuilder(filereader).build();
        List<String[]> allData = csvReader.readAll();

        // print Data
        for (String[] row : allData) {
            for (String cell : row) {
                fin += (cell + " ");

            }
        }
        return fin;
    }
}
