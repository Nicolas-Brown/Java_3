import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.*;

import com.opencsv.*;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.Slider;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import javafx.util.Duration;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;

public class Controller implements Initializable{
    @FXML
    private Pane pane;
    @FXML
    private Label lab_Song;
    @FXML
    private Button btn_Play, btn_Pause, btn_Reset, btn_Previous, btn_Next;
    @FXML
    private Slider slid_Volume;
    @FXML
    private ProgressBar progBar_Song;
    @FXML
    private Button btn_Help;

    private Media media;
    private MediaPlayer mediaPlayer;

    private DoublyLinkedList<File> songs;

    private File directory;
    private File[] files;

    private int songNumber = 0;
    private Timer timer;
    private TimerTask task;

    private boolean running;

    private static final String filePath = "Csv";


    @Override
    public void initialize(URL arg0, ResourceBundle arg1){
        btn_Help.setOnAction(e -> AlertBox.AlertBox("Help Window","Play : plays the current song, " + "\n" +
                "Pause : pauses the current song, " + "\n" +
                "Reset : resets the current song, " + "\n" +
                "Previous : selects the previous song, " + "\n" +
                "Next : selects the next song, " + "\n" +
                "Slider : changes the volume of the music player, " + "\n" +
                "Write Playlist To CSV And Close MP3 Player : merge sorts the playlist, saves it to a csv and closes the music player " + "\n"));
        songs = new DoublyLinkedList<File>();

        directory = new File("music");

        files = directory.listFiles();

        if(files != null) {

            for(File file : files) {

                songs.addLast(file);
            }
        }

        media = new Media(songs.searchAt(songNumber).toURI().toString());
        mediaPlayer = new MediaPlayer(media);

        lab_Song.setText(songs.searchAt(songNumber).getName());

        slid_Volume.valueProperty().addListener(new ChangeListener<Number>() {

            @Override
            public void changed(ObservableValue<? extends Number> arg0, Number arg1, Number arg2) {

                mediaPlayer.setVolume(slid_Volume.getValue() * 0.01);
            }
        });
    }

    public void playMedia() {
        beginTimer();
        mediaPlayer.setVolume(slid_Volume.getValue() * 0.01);
        mediaPlayer.play();
    }

    public void pauseMedia() {
        cancelTimer();
        mediaPlayer.pause();
    }

    public void resetMedia() {
        progBar_Song.setProgress(0);
        mediaPlayer.seek(Duration.seconds(0));
    }

    public void previousMedia() {
        if(songNumber > 0) {

            songNumber--;

            mediaPlayer.stop();

            if(running) {

                cancelTimer();
            }

            media = new Media(songs.searchAt(songNumber).toURI().toString());
            mediaPlayer = new MediaPlayer(media);

            lab_Song.setText(songs.searchAt(songNumber).getName());

            playMedia();
        }
        else {

            songNumber = songs.getSize() - 1;

            mediaPlayer.stop();

            if(running) {

                cancelTimer();
            }

            media = new Media(songs.searchAt(songNumber).toURI().toString());
            mediaPlayer = new MediaPlayer(media);

            lab_Song.setText(songs.searchAt(songNumber).getName());

            playMedia();
        }
    }

    public void nextMedia() {
        if(songNumber < songs.getSize() -1) {

            songNumber ++;

            mediaPlayer.stop();

            if(running) {
                cancelTimer();
            }

            media = new Media(songs.searchAt(songNumber).toURI().toString());
            mediaPlayer = new MediaPlayer(media);

            lab_Song.setText(songs.searchAt(songNumber).getName());

            playMedia();
        }
        else {

            songNumber = 0;

            mediaPlayer.stop();

            media = new Media(songs.searchAt(songNumber).toURI().toString());
            mediaPlayer = new MediaPlayer(media);

            lab_Song.setText(songs.searchAt(songNumber).getName());

            playMedia();
        }
    }

    public void beginTimer() {

        timer = new Timer();

        task = new TimerTask() {

            public void run() {

                running = true;
                double current = mediaPlayer.getCurrentTime().toSeconds();
                double end = media.getDuration().toSeconds();
                progBar_Song.setProgress(current/end);

                if(current/end == 1) {

                    cancelTimer();
                }
            }
        };

        timer.scheduleAtFixedRate(task, 0, 1000);
    }

    public void cancelTimer() {

        running = false;
        timer.cancel();
    }

    public void writeDataAtOnce1(String filePath) throws Exception{
        // first create file object for file placed at location
        // specified by filepath
        File file = new File(filePath);

        var node = songs.mergeSort(songs.getHead());

        // create FileWriter object with file as parameter
        FileWriter outputfile = new FileWriter(file);

        // create CSVWriter object filewriter object as parameter
        CSVWriter writer = new CSVWriter(outputfile);

        // create a List which contains String array
        List<String[]> data = new ArrayList<String[]>();
        data.add(new String[] { songs.print(node) });
        writer.writeAll(data);

        // closing writer connection
        writer.close();
    }

    public void closeMedia() throws Exception{
        if(running) {
            pauseMedia();
            cancelTimer();
        }
        writeDataAtOnce1(filePath);
        System.exit(0);
    }
}