import org.junit.Test;

import java.util.HashMap;

import static org.junit.Assert.assertEquals;

public class Testing {
    @Test
    public void loginTest() {
        loginController login = new loginController();
        //create a HashMap object
        HashMap<String, String> loginInfo = new HashMap<>();
        loginInfo.put(login.getAdminUserHash(), login.getAdminPassHash());
        for(String i : loginInfo.keySet()) {
            String confirm = (i + loginInfo.get(i));
            assertEquals(confirm, "-21395376491281629883");
        }
    }
}
