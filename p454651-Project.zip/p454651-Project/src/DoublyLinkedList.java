import java.io.File;

public class DoublyLinkedList<E> {

    private static Node head;
    private static Node tail;
    private static int size;

    public DoublyLinkedList() {
        size = 0;
    }

    //this class keeps track of each element information
    private static class Node {
        String data;
        File element;
        Node next;
        Node prev;

        public Node (File element, Node next, Node prev) {
            this.data = element.toString();
            this.element = element;
            this.next = next;
            this.prev = prev;
        }
    }

    static Node current = head;

    //return whether the list is empty or not
    public boolean isEmpty() {
        return size == 0;
    }

    //adds element at the starting of the linked list
    public void addLast(File element) {
        Node temp = new Node(element, null, tail);

        if(tail != null) {
            tail.next = temp;
        }
        tail = temp;

        if(head == null) {
            head = temp;
        }
        size++;
    }

    //this method searches the linked list
    public static File searchAt(int position){
        Node temp = head;


        if(position == 0) {
            return temp.element;
        } for(int i = 1; i <= size; i++) {
            temp = temp.next;
            if(i == position)
            {
                break;
            }
        }
        return temp.element;
    }

    public int getSize() {
        return size;
    }

    public Node split(Node head) {
        Node fast = head, slow = head;
        while (fast.next != null && fast.next.next != null) {
            fast = fast.next.next;
            slow = slow.next;
        }
        Node temp = slow.next;
        slow.next = null;
        return temp;
    }

    public Node mergeSort(Node node) {
        if (node == null || node.next == null) {
            return node;
        }
        Node second = split(node);

        // Recur for left and right halves
        node = mergeSort(node);
        second = mergeSort(second);

        // Merge the two sorted halves
        return merge(node, second);
    }

    // Function to merge two linked lists
    public Node merge(Node first, Node second) {
        // If first linked list is empty
        if (first == null) {
            return second;
        }

        // If second linked list is empty
        if (second == null) {
            return first;
        }

        // Pick the smaller value
        if (first.element.compareTo(second.element) == -1) {
            first.next = merge(first.next, second);
            first.next.prev = first;
            first.prev = null;
            return first;
        } else {
            second.next = merge(first, second.next);
            second.next.prev = second;
            second.prev = null;
            return second;
        }
    }

    public static Node getHead() {
        return head;
    }

    public String print(Node node) {
        Node temp = node;
        String output = "";
        while (node != null) {
            output +=(node.element.toString() + ", ");
            temp = node;
            node = node.next;
        }
        return output;
    }

    public static Node middleNode(Node start, Node last) {
        if (start == null) {
            return null;
        }
        Node slow = start;
        Node fast = start.next;

        while (fast != last)
        {
            fast = fast.next;
            if (fast != last)
            {
                slow = slow.next;
                fast = fast.next;
            }
        }
        return slow;
    }
}
