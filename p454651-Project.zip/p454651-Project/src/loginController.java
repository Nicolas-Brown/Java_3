import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import java.io.IOException;
import java.net.URL;
import java.util.HashMap;
import java.util.ResourceBundle;

public class loginController implements Initializable {
    @FXML
    private TextField txt_User;
    @FXML
    private PasswordField txt_Pass;
    @FXML
    private Button btn_Login;

    private String adminUser = "p454651";
    private String adminPass = "Password";
    private String adminUserHash = Integer.toString(adminUser.hashCode());
    private String adminPassHash = Integer.toString(adminPass.hashCode());
    private String entered;


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        //create a HashMap object
        HashMap<String, String> loginInfo = new HashMap<>();
        loginInfo.put(adminUserHash, adminPassHash);
        btn_Login.setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent event) {
                entered = Integer.toString(txt_User.getText().hashCode()) + Integer.toString(txt_Pass.getText().hashCode());
                for(String i : loginInfo.keySet()) {
                    String confirm = (i + loginInfo.get(i));
                    Parent root;
                    if (entered.equalsIgnoreCase(confirm)) {
                        try {
                            root = FXMLLoader.load(getClass().getClassLoader().getResource("MusicPlayer.fxml"));
                            Stage stage = new Stage();
                            stage.setTitle("MP3 Player");
                            stage.setScene(new Scene(root));
                            stage.show();
                            // Hide this current window (if this is what you want)
                            ((Node) (event.getSource())).getScene().getWindow().hide();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        });
    }

    public String getAdminUserHash() {
        return adminUserHash;
    }

    public String getAdminPassHash() {
        return adminPassHash;
    }
}
