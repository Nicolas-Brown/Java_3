import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;

public class Server {
    public static int count = 0;
    //admin login
    public static String adminUser = "p454651";
    public static String adminPass = "Password";
    public static String adminUserHash = Integer.toString(adminUser.hashCode());
    public static String adminPassHash = Integer.toString(adminPass.hashCode());

    public Server() {}

    public static void main(String[] args) {
        // server is on port 1234
        try (ServerSocket serverSocket = new ServerSocket(1234)) {
            System.out.println("Server is listening on port #" + serverSocket.getLocalPort());
            // wait, listen and accept connection
            try (Socket clientSocket = serverSocket.accept()) {
                System.out.println("Connected from " + clientSocket.getInetAddress().getHostName() + " on #" + clientSocket.getLocalPort());

                // input stream from client
                BufferedReader inStream;
                inStream = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));

                // input stream from client
                BufferedReader inStreamUser;
                inStreamUser = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));

                // input stream from client
                BufferedReader inStreamPass;
                inStreamPass = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));

                // output stream to client
                DataOutputStream outStream;
                outStream = new DataOutputStream(clientSocket.getOutputStream());

                //create a HashMap object
                HashMap<String, String> loginInfo = new HashMap<>();
                loginInfo.put(adminUserHash, adminPassHash);

                // chatting loop
                while (true) {
                    // read a line from client
                    String inLine = inStream.readLine();
                    System.out.println("Received from client: " + inLine);
                    if (inLine.equalsIgnoreCase("login")) {
                        String inLinePass = inStreamPass.readLine();
                        for(String i : loginInfo.keySet()) {
                            String confirm = (i + loginInfo.get(i));
                            System.out.println(confirm);
                            if (inLinePass.equalsIgnoreCase(confirm)) {
                                // send message to server
                                outStream.writeBytes("access granted");
                                // carriage return
                                outStream.write(13);
                                // line feed
                                outStream.write(10);
                                // flush the stream line
                                outStream.flush();
                                count++;
                            }
                        }
                        if (count == 0){
                            // send message to server
                            outStream.writeBytes("access denied");
                            // carriage return
                            outStream.write(13);
                            // line feed
                            outStream.write(10);
                            // flush the stream line
                            outStream.flush();
                        } else {
                            // send message to server
                            outStream.writeBytes(" ");
                            // carriage return
                            outStream.write(13);
                            // line feed
                            outStream.write(10);
                            // flush the stream line
                            outStream.flush();
                        }
                    } else if (inLine.equalsIgnoreCase("add user")) {
                        String inLineUser = inStreamUser.readLine();
                        if(inLineUser.length() > 0) {
                            String inLinePass = inStreamPass.readLine();
                            loginInfo.put(inLineUser, inLinePass);
                            // send message to server
                            outStream.writeBytes("new user added");
                            // carriage return
                            outStream.write(13);
                            // line feed
                            outStream.write(10);
                            // flush the stream line
                            outStream.flush();
                        } else {
                            // send message to server
                            outStream.writeBytes(" ");
                            // carriage return
                            outStream.write(13);
                            // line feed
                            outStream.write(10);
                            // flush the stream line
                            outStream.flush();
                            break;
                        }
                    }


                    // if the client sends "quit", then stop
                    if (inLine.equalsIgnoreCase("quit")) {
                        System.out.println("Client Disconnected!!!");
                        break; // disconnect
                    }
                }
                inStream.close();
                outStream.close();
            }
        } catch (IOException e) {
            System.err.println("IOException occurred " + e);
        }
    }
    public String getUserHash() {
        return adminUserHash;
    }
    public String getPassHash() {
        return adminPassHash;
    }
}


