import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.HashMap;
import java.util.Scanner;

public class Client2 {
    public static String adminUser = "p454651";
    public static String adminPass = "Password";
    public static String adminUserHash = Integer.toString(adminUser.hashCode());
    public static String adminPassHash = Integer.toString(adminPass.hashCode());
    public static int count = 0;


    public Client2() {
    }

    public static void main(String[] args) {
        String host = (args.length < 1) ? null : args[0];
        try {
            Registry registry = LocateRegistry.getRegistry(host);
            Methods stub = (Methods) registry.lookup("Login");

            //Receives methods
            String login = stub.login();
            String addUser = stub.addUser();
            String loginData = stub.loginData();
            String loginUser = stub.loginUser();
            String loginPass = stub.loginPass();
            String addLoginData = stub.addLoginData();
            String addLoginUser = stub.addLoginUser();
            String addLoginPass = stub.addLoginPass();
            System.out.println(login);

            //create a HashMap object
            HashMap<String, String> loginInfo = new HashMap<>();
            loginInfo.put(adminUserHash, adminPassHash);

            //checks to see if the login data is the admin user
            for (String i : loginInfo.keySet()) {
                String confirm = (i + loginInfo.get(i));
                if (loginData.equalsIgnoreCase(confirm)) {
                    System.out.println("Username: " + loginUser + " Password: " + loginPass);
                    System.out.println("Access Granted");
                } else {
                    System.out.println("Username: " + loginUser + " Password: " + loginPass);
                    System.out.println("Access Denied");
                }
            }
            //adds data to the hash map
            System.out.println(addUser);
            loginInfo.put(Integer.toString(addLoginUser.hashCode()), Integer.toString(addLoginPass.hashCode()));

            for (String i : loginInfo.keySet()) {
                String confirm = (i + loginInfo.get(i));
                if (addLoginData.equalsIgnoreCase(confirm)) {
                    System.out.println("Username: " + addLoginUser + " Password: " + addLoginPass);
                    System.out.println("Access Granted");
                    count++;
                }
                if (count == 0) {
                    System.out.println("Username: " + addLoginUser + " Password: " + addLoginPass);
                    System.out.println("Access Denied");
                }
            }
        } catch (RemoteException | NotBoundException e) {
            System.err.println("Client exception: " + e.toString());
        }
    }
}