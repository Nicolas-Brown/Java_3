import org.junit.Test;

import java.util.HashMap;

import static org.junit.Assert.assertEquals;

public class Testing {
    Server server = new Server();
    @Test
    public void hashingTest() {
        HashMap<String, String> loginInfo = new HashMap<>();
        loginInfo.put(server.getUserHash(), server.getPassHash());
        for(String i : loginInfo.keySet()) {
            String confirm = (i + loginInfo.get(i));
            assertEquals("-21395376491281629883", confirm);
        }
    }

}
