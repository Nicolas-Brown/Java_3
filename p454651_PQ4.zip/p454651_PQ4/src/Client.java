import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Client {
    public static Socket socket;
    // output stream to server
    public static DataOutputStream outStream;
    // input stream from server
    public static DataInputStream inStream;

    public Client() {}

    public static void main(String[] args) throws IOException, UnknownHostException{
        if (args.length != 2) {
            System.out.println("Incorrect arguments used!");
            System.out.println("Usage: java ClientClass hostName port#");
            System.exit(1);
        }

        //get host
        String host = args[0];
        //get port num
        int port = Integer.valueOf(args[1]).intValue();

        //create socket for connection
        socket = new Socket(host, port);
        // get input/output streams
        inStream = new DataInputStream(socket.getInputStream());
        outStream = new DataOutputStream(socket.getOutputStream());

        login();

        socket.close();
        inStream.close();
        outStream.close();
    }

    private static void login() throws IOException{
        Scanner scanner = new Scanner(System.in);
        while(true) {
            System.out.println("would you like to 'login', 'add user' or 'quit'?");
            String lineInput = scanner.nextLine();
            if(lineInput.equalsIgnoreCase("login")) {
                // send message to server
                outStream.writeBytes(lineInput);
                // carriage return
                outStream.write(13);
                // line feed
                outStream.write(10);
                // flush the stream line
                outStream.flush();
                System.out.println("Please enter a username");
                String username = scanner.nextLine();
                System.out.println("Please enter a Password");
                String password = scanner.nextLine();
                String userHash = Integer.toString(username.hashCode());
                String passHash = Integer.toString(password.hashCode());
                if(username.length() > 0 && password.length() > 0) {
                    // send message to server
                    outStream.writeBytes(userHash + passHash);
                    // carriage return
                    outStream.write(13);
                    // line feed
                    outStream.write(10);
                    // flush the stream line
                    outStream.flush();
                }
            } else if(lineInput.equalsIgnoreCase("add user")) {
                // send message to server
                outStream.writeBytes(lineInput);
                // carriage return
                outStream.write(13);
                // line feed
                outStream.write(10);
                // flush the stream line
                outStream.flush();

                System.out.println("Please enter a username");
                String username = scanner.nextLine();
                String usernameHash = Integer.toString(username.hashCode());
                // send message to server
                outStream.writeBytes(usernameHash);
                // carriage return
                outStream.write(13);
                // line feed
                outStream.write(10);
                // flush the stream line

                System.out.println("Please enter a Password");
                String password = scanner.nextLine();
                String paswwordHash = Integer.toString(password.hashCode());
                // send message to server
                outStream.writeBytes(paswwordHash);
                // carriage return
                outStream.write(13);
                // line feed
                outStream.write(10);
                // flush the stream line
            }
            if(lineInput.equalsIgnoreCase("quit")) {
                //stop client chatting as well
                System.exit(0);
            }

            //print any message received from server
            int inByte;
            System.out.print("Server>>> ");
            while ((inByte = inStream.read()) != '\n') {
                System.out.write(inByte);
            }
            System.out.println();
        }
    }
}
