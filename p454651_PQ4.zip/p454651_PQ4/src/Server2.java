import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;

import java.nio.channels.AlreadyBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.HashMap;

public class Server2 implements Methods{

    public Server2() {}

    //declares login data
    @Override
    public String login() {
        return "login";
    }
    @Override
    public String loginUser() {
        return "p454651";
    }
    @Override
    public String loginPass() {
        return "Password";
    }
    @Override
    public String loginData() {
        return Integer.toString(loginUser().hashCode()) + Integer.toString(loginPass().hashCode());
    }

    //declares adding login data
    @Override
    public String addUser() {
        return "add user";
    }
    @Override
    public String addLoginUser() {
        return "Nicolas";
    }
    @Override
    public String addLoginPass() {
        return "Pass";
    }
    @Override
    public String addLoginData() {
        return Integer.toString(addLoginUser().hashCode()) + Integer.toString(addLoginPass().hashCode());
    }

    public static void main(String args[]) {
        try {
            Server2 obj = new Server2();
            Methods stub = (Methods) UnicastRemoteObject.exportObject(obj, 0);

            // Bind the remote object's stub in the registry
            Registry registry = LocateRegistry.getRegistry();
            registry.bind("Login", stub);
            System.err.println("Server ready");
        } catch (RemoteException | AlreadyBoundException | java.rmi.AlreadyBoundException e) {
            System.err.println("Server exception: " + e.toString());
        }
    }
}

