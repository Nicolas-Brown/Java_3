import java.rmi.Remote;
import java.rmi.RemoteException;
public interface Methods extends Remote {
    String login() throws RemoteException;
    String addUser() throws RemoteException;
    String loginData() throws RemoteException;
    String loginUser() throws RemoteException;
    String loginPass() throws RemoteException;
    String addLoginData() throws RemoteException;
    String addLoginUser() throws RemoteException;
    String addLoginPass() throws RemoteException;
}