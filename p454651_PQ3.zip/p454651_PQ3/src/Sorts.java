public class Sorts {
    String name;
    double average;

    public Sorts (String name, double average) {
        this.name = name;
        this.average = average;
    }
}
