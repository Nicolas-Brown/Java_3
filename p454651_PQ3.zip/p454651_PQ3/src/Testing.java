import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;

public class Testing {
    static int randomNumArray[] = { 10, 5, 3, 7, 8, 9, 1, 4, 2, 6};
    static int sortedNumArray[] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
    Main main = new Main();

    @Test
    @DisplayName("Bubble test")
    public void bubbleTest() {
        main.Bubble(randomNumArray);
        assertArrayEquals(sortedNumArray, randomNumArray);
    }

    @Test
    @DisplayName("in built test")
    public void inBuiltTest() {
        main.Inbuilt(randomNumArray);
        assertArrayEquals(sortedNumArray, randomNumArray);
    }

    @Test
    @DisplayName("merge test")
    public void mergeTest() {
        main.MergeSort(randomNumArray, 0, randomNumArray.length - 1);
        assertArrayEquals(sortedNumArray, randomNumArray);
    }

}
