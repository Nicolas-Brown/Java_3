import java.util.*;

public class Main {
    //Declares the variables
    static int lowerStaff = 100000;
    static int maxNum = 10000000;
    static int runs = 100;
    static double average;
    static double average2;
    static double average3;

    //declares the array
    static ArrayList arrayList = new ArrayList();
    static int numArray[] = new int[lowerStaff + 1];
    static StopWatch watch = new StopWatch();
    static Random random = new Random();
    static timeComparator timeComp = new timeComparator();

    public static void main(String[] args) {
        //creates a Random number generator
        for (int i = 0; i <= runs; i++) {
            for (int j = 0; j < lowerStaff; j++) {
                int randomInt = random.nextInt(maxNum);
                numArray[j] = randomInt;
            }
            //sorts numArray using inbuilt
            watch.reset();
            watch.start();
            Inbuilt(numArray);
            watch.stop();
            average += watch.getElapsedTime();
        }
        System.out.println("inbuilt sort completed");

        //creates a Random number generator
        for (int i = 0; i <= runs; i++) {
            for (int j = 0; j < lowerStaff; j++) {
                int randomInt = random.nextInt(maxNum);
                numArray[j] = randomInt;
            }

            //sorts numArray using merge
            watch.reset();
            watch.start();
            MergeSort(numArray, 0, numArray.length - 1);
            watch.stop();
            average2 += watch.getElapsedTime();
        }
        System.out.println("merge sort completed");

        //creates a Random number generator
        for (int i = 0; i <= runs; i++) {
            for (int j = 0; j < lowerStaff; j++) {
                int randomInt = random.nextInt(maxNum);
                numArray[j] = randomInt;
            }
            //sorts numArray using bubble
            watch.reset();
            watch.start();
            Bubble(numArray);
            watch.stop();
            average3 += watch.getElapsedTime();
        }
        System.out.println("bubble sort completed");
        average = average/100;
        average2 = average2/100;
        average3 = average3/100;
        arrayList.add(new Sorts("Bubble", average3));
        arrayList.add(new Sorts("inBuilt", average));
        arrayList.add(new Sorts("Merge", average2));


        Collections.sort(arrayList, new timeComparator());
        Iterator itr = arrayList.iterator();
        while (itr.hasNext()) {
            Sorts sort = (Sorts) itr.next();
            System.out.println(sort.name + " " + sort.average);
        }
    }

    public static void Inbuilt(int array[]) {
        Arrays.sort(array);
    }

    public static void Merge(int array[], int num1, int num2, int num3) {
        //find sizes of two arrays
        int n1 = num2 - num1 + 1;
        int n2 = num3 - num2;

        //create temp arrays
        int array1[] = new int[n1];
        int array2[] = new int[n2];

        //copy data to temp arrays
        for (int i = 0; i < n1; ++i)
            array1[i] = array[num1 + i];
        for (int j = 0; j < n2; ++j)
            array2[j] = array[num2 + 1 + j];

        // merge the temp arrays
        int i = 0, j = 0;
        int k = num1;
        while (i < n1 && j < n2) {
            if (array1[i] <= array2[j]) {
                array[k] = array1[i];
                i++;
            } else {
                array[k] = array2[j];
                j++;
            }
            k++;
        }
    }

    public static void MergeSort(int array[], int num1, int num3)
    {
        if (num1 < num3) {
            //find the middle point
            int num2 = num1+ (num3-num1)/2;

            //sort first and second halves
            MergeSort(array, num1, num2);
            MergeSort(array, num2 + 1, num3);

            //merge the sorted halves
            Merge(array, num1, num2, num3);
        }
    }

    public static void Bubble(int array[]) {
        int length = array.length;
        for (int i = 0; i < length - 1; i++) {
            for (int j = 0; j < length - i - 1; j++) {
                if (array[j] > array[j + 1]) {
                    // swap array[j + 1] and array[j]
                    int temp = array[j];
                    array[j] = array[j + 1];
                    array[j + 1] = temp;
                }
            }
        }
    }
}