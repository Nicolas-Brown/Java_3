import java.util.Comparator;

public class timeComparator implements Comparator {
    public timeComparator() {
    }

    public int compare(Object object1,Object oobject2){
        Sorts sort1=(Sorts)object1;
        Sorts sort2=(Sorts)oobject2;

        if(sort1.average == sort2.average)
            return 0;
        else if(sort1.average > sort2.average)
            return 1;
        else
            return -1;
    }
}
