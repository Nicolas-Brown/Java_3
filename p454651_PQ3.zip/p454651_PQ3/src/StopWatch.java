public class StopWatch {

    private double startTime;
    private double stopTime;

    public StopWatch() {
    }

    public void reset() {
        startTime = 0;
        stopTime = 0;
    }

    public void start() {
        startTime = System.nanoTime();
    }

    public void stop() {
        stopTime = System.nanoTime();
    }

    //elapsed time in milliseconds
    public double getElapsedTime() {
        return ((stopTime-startTime)/1000000000);
    }
}