import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.input.*;

import java.net.URL;
import java.util.ResourceBundle;

public class Controller implements Initializable{
    @FXML
    public ListView lst_toDo;
    @FXML
    public ListView lst_work;
    @FXML
    public ListView lst_comp;
    @FXML
    public Button btn_help;


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        btn_help.setOnAction(e -> AlertBox.AlertBox("Help Window","To use this application you have to click and drag the tasks from one box to the next from to-do to working to complete"));
        lst_toDo.getItems().add("Planning");
        lst_toDo.getItems().add("Initial Documenting");
        lst_toDo.getItems().add("Coding");
        lst_toDo.getItems().add("Final Documenting");
    }

    //To-Do listview controller
    public void toDoDragDetected(javafx.scene.input.MouseEvent event) {
        //allow move transfer mode
        Dragboard dboard = lst_toDo.startDragAndDrop(TransferMode.MOVE);

        // put a string on dragboard
        ClipboardContent content = new ClipboardContent();
        content.putString(String.valueOf(lst_toDo.getSelectionModel().getSelectedItems()));
        dboard.setContent(content);

        event.consume();
    }

    public void toDoDragDone(DragEvent dragEvent) {
        //If the data was successfully moved, clear it
        if(dragEvent.getTransferMode() == TransferMode.MOVE) {
            int selectedID = lst_toDo.getSelectionModel().getSelectedIndex();
            lst_toDo.getItems().remove(selectedID);
        }
    }

    //working listview controller
    public void workDragDetected(javafx.scene.input.MouseEvent event) {
        //allow move transfer mode
        Dragboard dboard = lst_work.startDragAndDrop(TransferMode.MOVE);

        // put a string on dragboard
        ClipboardContent content = new ClipboardContent();
        content.putString(String.valueOf(lst_work.getSelectionModel().getSelectedItems()));
        dboard.setContent(content);

        event.consume();
    }

    public void workDragDone(DragEvent dragEvent) {
        //If the data was successfully moved, clear it
        if(dragEvent.getTransferMode() == TransferMode.MOVE) {
            int selectedID = lst_work.getSelectionModel().getSelectedIndex();
            lst_work.getItems().remove(selectedID);
        }
    }

    public void workDragDropped(DragEvent dragEvent) {
        //if there is a string data on dragboard, read it and use it
        Dragboard dboard = dragEvent.getDragboard();
        boolean success = false;
        if(dboard.hasString() && dboard.getString() != "[]") {
            lst_work.getItems().add(dboard.getString());
            success = true;
        }
        dragEvent.setDropCompleted(success);
        dragEvent.consume();
    }

    public void workDragOver(DragEvent dragEvent) {
        //accept only if not dragged from the same node
        if (dragEvent.getGestureSource() != lst_work.getItems()) {
            dragEvent.acceptTransferModes(TransferMode.MOVE);
        }
        dragEvent.consume();
    }

    //complete listview controller
    public void compDragDropped(DragEvent dragEvent) {
        //if there is a string data on dragboard, read it and use it
        Dragboard dboard = dragEvent.getDragboard();
        boolean success = false;
        if(dboard.hasString() && dboard.getString() != "[]") {
            lst_comp.getItems().add(dboard.getString());
            success = true;
        }
        dragEvent.setDropCompleted(success);
        dragEvent.consume();
    }

    public void compDragOver(DragEvent dragEvent) {
        //accept only if not dragged from the same node
        if (dragEvent.getGestureSource() != lst_comp.getItems()) {
            dragEvent.acceptTransferModes(TransferMode.MOVE);
        }
        dragEvent.consume();
    }
    public String getWork() {
        return lst_work.getItems().toString();
    }
}
