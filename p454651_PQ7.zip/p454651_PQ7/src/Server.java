import java.io.*;
import java.net.*;
public class Server {
    public void Server() {
    }
    public static void main(String[] args) throws Exception {
        //create and accepts server socket
        ServerSocket serverSocket = new ServerSocket(1234);
        Socket socket = serverSocket.accept();

        //create a file input stream that reads the csv in the readCSV file
        FileInputStream fileInputStream = new FileInputStream("readCSV/Csv");

        //create a byte array
        byte byteArray[] = new byte[2000];

        //read file and save to byte array
        fileInputStream.read(byteArray, 0, byteArray.length);

        //create output stream
        OutputStream outputStream = socket.getOutputStream();

        //sends byte array to client
        outputStream.write(byteArray, 0, byteArray.length);
    }
}
