import org.junit.Test;
import java.io.*;

import static org.junit.Assert.assertEquals;

public class Testing {

    @Test
    public void csvTest() throws Exception{
        FileInputStream originalCSV = new FileInputStream("readCSV/Csv");
        FileInputStream newCSV = new FileInputStream("copyCSV/Csv");
        assertEquals(newCSV.read(), originalCSV.read());
    }
}
