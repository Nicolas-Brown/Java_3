import java.io.*;
import java.net.*;
public class Client {
    public void CLient() {
    }
    public static void main(String[] args) throws Exception{
        //create a socket
        Socket socket = new Socket("localhost", 1234);

        //create an input stream
        InputStream inputStream = socket.getInputStream();

        //create file in copyCSV
        FileOutputStream fileOutputStream = new FileOutputStream("copyCSV/Csv");

        //create a byte array
        byte byteArray[] = new byte[2000];

        //read file and save to byte array
        inputStream.read(byteArray, 0, byteArray.length);

        //sends byte array to client
        fileOutputStream.write(byteArray, 0, byteArray.length);
    }
}
