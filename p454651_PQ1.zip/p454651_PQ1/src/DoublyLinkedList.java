import java.nio.file.Files;
import java.util.NoSuchElementException;
public class DoublyLinkedList<E> {

    private Node head;
    private Node tail;
    private int size;

    public DoublyLinkedList() {
        size = 0;
    }
    //this class keeps track of each element information
    private class Node {
        String element;
        Node next;
        Node prev;

        public Node(String element, Node next, Node prev) {
            this.element = element;
            this.next = next;
            this.prev = prev;
        }
    }
    //returns the size of the linked list
    public void size() {
        System.out.println("size of the list: " + size);
    }

    //return whether the list is empty or not
    public boolean isEmpty() { return size == 0; }

    //adds element at the starting of the linked list
    public void addFirst(String element) {
        Node tmp = new Node(element, head, null);
        if(head != null ) {
            head.prev = tmp;
        }
        head = tmp;
        if(tail == null) {
            tail = tmp;
        }
        size++;
        System.out.println("adding: "+element);
    }

    //adds element at the end of the linked list
    public void addLast(String element) {

        Node tmp = new Node(element, null, tail);
        if(tail != null) {
            tail.next = tmp;
        }
        tail = tmp;
        if(head == null) {
            head = tmp;
        }
        size++;
        System.out.println("adding: "+element);
    }

    //this method walks forward through the linked list
    public void iterateForward(){

        System.out.println("iterating forward..");
        Node tmp = head;
        while(tmp != null){
            System.out.println(tmp.element);
            tmp = tmp.next;
        }
    }

    //this method walks backward through the linked list
    public void iterateBackward(){

        System.out.println("iterating backword..");
        Node tmp = tail;
        while(tmp != null){
            System.out.println(tmp.element);
            tmp = tmp.prev;
        }
    }

    //this method removes element from the start of the linked list
    public String removeFirst() {
        if (size == 0) throw new NoSuchElementException();
        Node tmp = head;
        head = head.next;
        head.prev = null;
        size--;
        System.out.println("deleted: "+tmp.element);
        return tmp.element;
    }

    //this method removes element from the end of the linked list
    public String removeLast() {
        if (size == 0) throw new NoSuchElementException();
        Node tmp = tail;
        tail = tail.prev;
        tail.next = null;
        size--;
        System.out.println("deleted: "+tmp.element);
        return tmp.element;
    }
    //print all the nodes of doubly linked list
    public void printNodes() {
        //Node current will point to head
        Node current = head;
        if(head == null) {
            System.out.println("Doubly linked list is empty");
            return;
        }
        System.out.println("Nodes of doubly linked list: ");
        while(current != null) {
            //Print each node and then go to next.
            System.out.print(current.element);
            System.out.println();
            current = current.next;
        }
    }
    public String getFirtst() {
        return head.element;
    }

    public String getLast() {
        return tail.element;
    }
}