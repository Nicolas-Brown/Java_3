import java.lang.reflect.Constructor;

public class Main {
    public static void main(String[] args) throws Exception{
        DoublyLinkedList dlList = new DoublyLinkedList();
        Countries count = new Countries();

        //Countries.Cities city = count.new Cities();

        //adding the first Country and city
        count.setCountriesname("Australia");
        count.createCities("Canberra");
        dlList.addLast(count.toString());

        //adding the second Country and city
        count.setCountriesname("United States of America");
        count.createCities("Washington. D.C.");
        dlList.addLast(count.toString());

        //adding the third Country and city
        count.setCountriesname("Anguilla");
        count.createCities("The Valley");
        dlList.addLast(count.toString());

        //adding the fourth Country and city
        count.setCountriesname("Fiji");
        count.createCities("Suva");
        dlList.addLast(count.toString());

        //printing out the doubly linked list
        dlList.printNodes();

        System.out.println();

        //shows size of doubly linked list
        dlList.size();
    }
}


