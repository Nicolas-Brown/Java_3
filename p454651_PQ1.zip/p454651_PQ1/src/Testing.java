import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class Testing {
    @Test
    @DisplayName("Country insert test")
    public void testCountry() {
        Countries countries = new Countries();

        countries.setCountriesname("Fiji");
        countries.createCities("Suva");
        assertEquals("Fiji, Suva", countries.toString());
    }

    @Test
    @DisplayName("Linked list first and last test")
    public void testList() {
        DoublyLinkedList<Countries> dlList = new DoublyLinkedList<>();
        Countries countries = new Countries();

        countries.setCountriesname("Fiji");
        countries.createCities("Suva");
        dlList.addFirst(countries.toString());
        countries.setCountriesname("Australia");
        countries.createCities("Canberra");
        dlList.addFirst(countries.toString());
        countries.setCountriesname("United States of America");
        countries.createCities("Washington. D.C.");
        dlList.addLast(countries.toString());
        assertEquals("Australia, Canberra", dlList.getFirtst());
        assertEquals("United States of America, Washington. D.C.", dlList.getLast());
    }
}
