public class Countries {
    private String countName;
    private String cityName;

    public Countries() {
    }

    //sets country name to the new input
    public void setCountriesname(String nameCount) {
        countName = nameCount;
    }

    //returns country and city names
    public String toString() {
        return countName + ", " + cityName;
    }

    //sets city name to the new input
    public void createCities(String cities) {
        Cities city = new Cities();
        city.setCityname(cities);
    }

    private class Cities {

        //sets city name to the new input
        public void setCityname(String nameCity){
            cityName = nameCity;
        }
    }
}
